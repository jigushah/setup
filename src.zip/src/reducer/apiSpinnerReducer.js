import * as actions from '../action/apiSpinnerAction';

const initialState = 0;

const totalApiCalls = (state = initialState, action) => {
  switch (action.type) {
    case actions.API_REQUEST:
      return state+1;
    case actions.API_REQUEST_SUCCESS:
      return (state > 0 ? state - 1 : state);
    case actions.API_REQUEST_FAILURE:
      return (state > 0 ? state - 1 : state);
    default:
      return state
  }
}

export default totalApiCalls;