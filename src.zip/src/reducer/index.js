import { combineReducers } from "redux";
import { reducer as toastrReducer } from "react-redux-toastr";
import apiSpinnerReducer from './apiSpinnerReducer'
const appReducer = combineReducers({
    toastr: toastrReducer,
    totalApiCalls: apiSpinnerReducer,
  });
  
  const rootReducer = (state, action) => {
    if (action.type === "LOGOUT") {
      const { articles } = state;
      state = { articles };
    }
  
    return appReducer(state, action);
  };
  
  
  export default rootReducer;