import React, { PureComponent } from "react";

class MainLayout extends PureComponent {
  state = {
    width: window.innerWidth,
  };

  componentDidMount () {
    if (window !== "undefined") {
      window.addEventListener("resize", this.updateWidth, false);
    }
  }

  componentWillUnmount () {
    if (window !== "undefined") {
      window.removeEventListener("resize", this.updateWidth, false);
    }
  }

  render () {
    return (
        <div>
            <main>{this.props.children}</main>
        </div>
    );
  }
}

export default MainLayout;
