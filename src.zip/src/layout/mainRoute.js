
import React, { Component, Fragment } from "react";
import { connect } from 'react-redux';
import { 
  // Redirect, 
  Route } from "react-router-dom";
import MainLayout from "./mainLayout";

class MainLayoutRoute extends Component {
    render() {
      const { render, ...rest } = this.props;
      return (
        <Route
          {...rest}
          render={matchProps => (
            <Fragment>
                {/* <Redirect from={matchProps.path} to={"/login"} /> */}
                <MainLayout computedMatch={this.props.computedMatch}>
                    {render(matchProps)}
                </MainLayout>
            </Fragment>
          )}/>
      );
    }
  }
  
  const mapStateToProps = (state) => {
    return {
      
    }
  }
  
  export default connect(mapStateToProps)(MainLayoutRoute);