export const ERROR_401_UNAUTHORIZED = "ERROR_401_UNAUTHORIZED";
export const ERROR_403_FORBIDDEN = "ERROR_403_FORBIDDEN";
export const ERROR_500 = "ERROR_500";

export const ERROR_401_UNAUTHORIZED_SUCCESS = "ERROR_401_UNAUTHORIZED_SUCCESS";
export const ERROR_403_FORBIDDEN_SUCCESS = 'ERROR_403_FORBIDDEN_SUCCESS';
export const ERROR_500_SUCCESS = 'ERROR_500_SUCCESS';

export const errorUnauthorized = () => {
  return {
    type: ERROR_401_UNAUTHORIZED,
    payload: true
  }
}

export const errorForbidden = () => {
  return {
    type: ERROR_403_FORBIDDEN,
    payload: true
  }
}

export const error = () => {
  return {
    type: ERROR_500,
    payload: true
  }
}

export const errorUnauthorizedResolved = () => {
  return {
    type: ERROR_401_UNAUTHORIZED_SUCCESS,
    payload: false
  }
}

export const errorForbiddenResolved = () => {
  return {
    type: ERROR_403_FORBIDDEN_SUCCESS,
    payload: false
  }
}

export const errorResolved = () => {
  return {
    type: ERROR_500_SUCCESS,
    payload: false
  }
}