const BaseUrl = '';

export default {
    login: `${BaseUrl}/aa`
}