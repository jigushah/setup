import {
  HttpClient
} from './httpClient';
import * as apiSpinnerActions from '../action/apiSpinnerAction';
import * as errorPagesActions from '../action/errorAction';

const sendHttpCall = (dispatch, type, url, values, config = {}) => {
  return new Promise((resolve, reject) => {
    dispatch(apiSpinnerActions.sendApiRequest())
    return HttpClient[type](url, values, config)
      .then(res => {
        dispatch(apiSpinnerActions.apiRequestSuccess())
        resolve(res);
      })
      .catch(err => {
        dispatch(apiSpinnerActions.apiRequestFailure())
        if (err.response) {
          if (err.response.status == 401) {
            dispatch(errorPagesActions.errorUnauthorized())
          } else if (err.response.status == 403) {
            dispatch(errorPagesActions.errorForbidden())
          } else if (err.response.status == 500) {
            dispatch(errorPagesActions.error())
          }
        }
        reject(err)
      })
  })
}

export default {
  sendHttpCall
};