import React, { Suspense, lazy } from "react";
import './App.css';
import { store,persistor } from "./store/index";
import ReduxToastr from 'react-redux-toastr'
import { PersistGate } from "redux-persist/integration/react";
import { Provider } from "react-redux";
import Spinner from './component/spinner';

const LazyApp = lazy(() => import("./routes/index"));

function App() {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
      <Suspense fallback={<Spinner />}>
        <LazyApp/>
        <ReduxToastr
            timeOut={4000}
            newestOnTop={false}
            preventDuplicates
            position="top-left"
            transitionIn="fadeIn"
            transitionOut="fadeOut"
            progressBar
            closeOnToastrClick/>
      </Suspense>
    </PersistGate>
   </Provider>
  );
}

export default App;
