import React, { Component, lazy, Suspense } from "react";
import { createBrowserHistory } from 'history'
import { Switch, Router } from "react-router-dom";
import Spinner from "../component/spinner";
import MainLayoutRoutes from "../layout/mainRoute";
const LazyDashboard = lazy(() => import("../page/dashboard"));

class RouterClass extends Component {
    render() {
        return (
            <Router 
                basename="/" 
                history={createBrowserHistory()} >
                <Switch>
                    <MainLayoutRoutes
                    exact
                    path="/" // ":id/login"
                    render={matchprops => (
                        <Suspense fallback={<Spinner />}>
                            <LazyDashboard {...matchprops} />
                        </Suspense>
                    )}/>
                    <MainLayoutRoutes
                    exact
                    path="/login" // ":id/login"
                    render={matchprops => (
                        <Suspense fallback={<Spinner />}>
                            <LazyDashboard {...matchprops} />
                        </Suspense>
                    )}/>
                </Switch>
           </Router>
        )}
}

export default RouterClass
